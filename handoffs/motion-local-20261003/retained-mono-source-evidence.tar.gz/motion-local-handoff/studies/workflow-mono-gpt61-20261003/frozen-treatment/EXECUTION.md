# MONO / Motion treatment

Original vanilla JavaScript, CSS, Three.js 0.180.0 and Vite 7.3.6 build. Production preview: http://127.0.0.1:4342. Run `npm run build` then `npm run preview -- --host 127.0.0.1 --port 4342 --strictPort` from this directory.

Built from scratch within the 20-minute window. Read BRIEF, repository AGENTS, all four freshly installed Motion skills and the installed bounded workflow graph. No other arm or earlier app source inspected; existing node_modules is dependency cache only. No external fonts, assets, APIs or credentials.

## Product

Procedural continuous headband, soft underside, aluminium cups, joints, cushions and separated driver meshes, controlled studio lights and local radial shadow. Scroll-linked form / construction / finish chapters, bounded pointer drag and button rotation, exploded view with Restore and Reset, retargeted material interpolation, editorial acoustic section, responsive finish picker, animated purchase bar, reversible cart, quantity bounds, removal and seven-second Undo, keyboard dialog loop and Escape, local concept order review. All specifications are labelled illustrative and checkout explicitly local.

## Checks and evidence

Production builds passed. Three.js produces the ordinary Vite >500 kB chunk advisory. Fresh headed Chrome only, closed after each ordinary check; real installed stdio MCP via local-trial-tool.mjs. The installed package SHA supplied by coordinator is a2de24effb62e86f7d51b71b044728d24770a3eb9eee27c8e8ff2b2fd474bb45.

Ordinary Playwright checks and screenshots are in checks/; desktop and mobile unforced remove/Undo restored quantity two and chosen material. Desktop Ember total was $900; mobile Chalk restored quantity two. Mobile 360×800 had no horizontal overflow. Initial keyboard check lacked a settled-state wait and reported false; the actual MCP ordered key journey established aria-hidden=false with Ember quantity two. Final checks are recorded separately when available.

### Evidence-led repair 1

Construction baseline 601c39c4-b8ed-4ac8-8bac-5889374c4aaa: sufficient GPU-backed cadence (48.5 ms maximum gap), DOM canvas contracts all passed. Actual decoded intermediate pixels showed the mesh still separated after Inside was toggled off. Source cause: `(exploded || chapter === 1)` forced the exploded pose despite the explicit restore state. Narrow repair makes the explicit `exploded` state own separation; chapter camera rotation remains and the actual construction link still opens the parts.

Same unchanged recipe/viewport/contracts after: daf92b6b-a95a-4853-ab33-6a3106e86276. All contracts passed, maximum gap 41.6 ms. motion_compare confirmed comparability and final-equivalent DOM state, with both canvas rectangles stationary. This is a visual internal-mesh repair, not a detector metric improvement. Viewed actual motion_frames after plus a full saved-video contact sheet (checks/after-film.png), which shows opening and reassembly. Before frame 4600 ms was clamped to videoSeekMs 7080 rather than expected 8524; precise localization from that frame is unavailable. Full video evidence and intermediate frames were inspected without claiming exact timing.

### Evidence-led repair 2

Cart baseline c051b1a7-1839-49d0-8207-86bae8a2982e exercised Ember add, quantity two, removal, timely Undo, closing and immediate keyboard reopening. Correct final Ember quantity two / $900. Sufficient cadence (76.4 ms maximum gap), but the frozen 45 px/16.667 ms drawer speed budget failed at 54.205. Inspected bounded source/trace and real decoded pixels. CSS .55 s travel with steep initial cubic easing accounts for the speed. Narrow second/final repair lengthens the drawer travel to .8 s, preserving reversal, interaction and the original budget.

After b76c3841-dc74-44f4-8ca7-5772f244e899: correct final restored state; observed normalized speed 37.225, but 284.7 ms sampling gap and 112.8 ms read lag make temporal assertions inconclusive. Retained this run. No third source repair. One bounded environment repeat is recorded separately. No perceptual smoothness inferred from normalized displacement.

## Limits

The concept uses one cart line; adding another finish replaces that line, as shown by current selected finish. No remote persistence or payment. Reduced motion keeps all controls and makes spatial retargeting immediate. Canvas metrics cannot measure internal 3D movement. Host recording alignment is approximate; clamped seeks are not exact trace localization. The render loop still updates when the page is below the hero (and skips rendering only while document is hidden); this modest geometry was not performance-benchmarked. No claim of general model or workflow superiority.
