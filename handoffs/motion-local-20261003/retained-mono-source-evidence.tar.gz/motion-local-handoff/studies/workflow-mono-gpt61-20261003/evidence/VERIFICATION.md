# Pretrial verification

The native headed recording uses Chromium 152.0.7977.64 and Intel Mesa ADL GT2 on this laptop. The decoded four-corner calibration and actual existing Three.js scene show the complete 1280 × 800 viewport. Only native padding is cropped; the original browser video is retained. The scene sampling gate passed with a maximum rAF gap of 62.5 ms and actual-read gap of 49.8 ms. This is recorder preflight on the earlier frozen app, not a new trial endpoint.

A fresh npm tarball consumer installed real dependencies, imported the library, parsed four client configuration formats, installed all four complete skills, and completed actual official-SDK MCP handshake and motion_list. Browser launch was explicitly skipped in that setup run to avoid contention with the control arm. The separate actual GPU preflight provides browser evidence; treatment MCP captures and final consumer browser checks follow later.

The new native surface validation and velocity interpretation unit tests passed. Existing core/coverage/integrity/frame tests and workflow validation passed. The failure-evidence browser regression passed before the last strengthened assertions; a final rerun is required. CI runs the strengthened browser case.

Recorded-frame alignment still uses approximate host offsets. Full original recordings are the visual evidence; these offsets do not establish exact video/trace synchronization. A native GPU string alone does not establish pixel coverage, perceptual smoothness or functional correctness.

Exports replace only the exact repository prefix in copied text. Frozen source and source manifest bytes are never reformatted. PREFLIGHT-EXPORT.json retains original artifact digests and transformations.
