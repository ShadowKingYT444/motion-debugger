export default {server:{host:'127.0.0.1',port:4341,strictPort:true},preview:{host:'127.0.0.1',port:4341,strictPort:true},build:{rollupOptions:{output:{manualChunks:{three:['three']}}}}};
