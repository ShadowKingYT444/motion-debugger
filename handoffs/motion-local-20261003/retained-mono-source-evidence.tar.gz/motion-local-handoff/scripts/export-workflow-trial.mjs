// Export complete real recordings in registered order. Never trim, retime or interpolate.
import {readFile,mkdir,writeFile,copyFile} from 'node:fs/promises';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const [manifestFile,mediaDirectory]=process.argv.slice(2);
if(!manifestFile||!mediaDirectory||process.argv.length!==4)throw Error('Use export-workflow-trial.mjs recordings.json media-directory');
const input=JSON.parse(await readFile(manifestFile,'utf8')),media=path.resolve(mediaDirectory);
await mkdir(media,{recursive:true});
const provenance=[];
const run=(args)=>{const result=spawnSync('ffmpeg',['-hide_banner','-loglevel','error','-nostdin','-y',...args],{stdio:'inherit',timeout:60000});if(result.status!==0)throw Error(`Video export failed (${result.status})`)};
for(const arm of ['control','treatment']){
  const clips=input[arm];
  if(!Array.isArray(clips)||clips.length!==3||clips.map(c=>c.clip).join(',')!=='story,finish,cart')throw Error('Exactly three original registered clips per arm are required');
  const parts=[];
  for(const [index,clip]of clips.entries()){
    const report=JSON.parse(await readFile(clip.report,'utf8'));
    if(!report.artifacts.video)throw Error('A clip has no actual recording; do not fabricate replacement footage');
    const source=path.resolve(report.artifacts.video),bytes=await readFile(source);
    const part=path.join(path.dirname(path.resolve(manifestFile)),`${arm}-export-${index}.mp4`);
    const label=`${arm==='control'?'ORDINARY':'MOTION'} / GPT-6.1 STANDARD / ${clip.clip.toUpperCase()}${report.status==='incomplete'?' / INCOMPLETE':''}`;
    run(['-threads','1','-i',source,'-filter_threads','1','-vf',`pad=iw:ih+28:0:28:color=0x222222,drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf:text='${label}':fontcolor=white:fontsize=14:x=16:y=6`,'-an','-c:v','libx264','-threads','1','-preset','veryfast','-crf','21','-pix_fmt','yuv420p','-movflags','+faststart',part]);
    parts.push(part);
    provenance.push({arm,order:index,clip:clip.clip,captureId:report.id,status:report.status??'complete',sourceSha256:createHash('sha256').update(bytes).digest('hex'),videoOffsetMs:report.artifacts.videoOffsetMs,recordingTransform:report.artifacts.recordingTransform??null,sufficientEvidence:report.metrics.sufficientEvidence,maxSampleGapMs:report.metrics.maxSampleGapMs,export:'Complete original clip including pre-roll. No trim, retiming or interpolation; label bar added above recorded viewport.'});
    if(index===0)await copyFile(report.artifacts.poster,path.join(media,`${arm}-poster.png`));
  }
  const concat=path.join(path.dirname(path.resolve(manifestFile)),`${arm}-concat.txt`);
  // ffmpeg concat quoting; these are generated local paths, never shell commands.
  await writeFile(concat,parts.map(p=>`file '${p.replaceAll("'","'\\''")}'`).join('\n')+'\n');
  run(['-f','concat','-safe','0','-i',concat,'-c','copy','-movflags','+faststart',path.join(media,`${arm}.mp4`)]);
}
run(['-i',path.join(media,'control-poster.png'),'-i',path.join(media,'treatment-poster.png'),'-filter_complex','[0:v][1:v]hstack=inputs=2,scale=1280:400','-frames:v','1',path.join(media,'comparison.png')]);
for(const arm of ['control','treatment']){
  const file=path.join(media,`${arm}.mp4`);provenance.push({arm,exportSha256:createHash('sha256').update(await readFile(file)).digest('hex'),file:`${arm}.mp4`});
}
await writeFile(path.join(media,'EXPORT.json'),JSON.stringify(provenance,null,2)+'\n');
console.log('Exported all complete actual source clips, including incomplete outcomes where present.');
