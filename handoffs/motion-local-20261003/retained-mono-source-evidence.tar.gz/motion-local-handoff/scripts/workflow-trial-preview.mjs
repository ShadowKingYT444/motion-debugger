// Read-only localhost review of the frozen GPT-6.1 trial. No build or source mutation.
import express from 'express';
import path from 'node:path';
import {readFile} from 'node:fs/promises';
const root=process.cwd(),study=path.join(root,'studies/workflow-mono-gpt61-20261003'),media=path.join(root,'docs/assets/workflow-mono-gpt61-20261003');
const servers=[];
for(const [arm,port]of [['control',4344],['treatment',4345]]){
  const app=express();app.use(express.static(path.join(study,`frozen-${arm}`,'dist')));
  servers.push(app.listen(port,'127.0.0.1',()=>console.log(`FROZEN_${arm.toUpperCase()} http://127.0.0.1:${port}`)));
}
const app=express();app.use('/media',express.static(media));
app.get('/',async(_,res)=>{
  const result=await readFile(path.join(study,'RESULT.json'),'utf8').then(JSON.parse).catch(()=>({summary:'Final independent workflow comparison is being verified. No quality advantage is assumed.'}));
  const escape=text=>String(text).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
  res.type('html').send(`<!doctype html><html lang="en"><head><meta name="viewport" content="width=device-width"><title>Motion Debugger · GPT-6.1 workflow trial</title><style>body{font:16px system-ui;max-width:1280px;margin:32px auto;padding:20px;background:#f4f2ed;color:#242624}section{display:grid;grid-template-columns:1fr 1fr;gap:24px}video{width:100%;background:#deddd7}h1{font-size:36px;letter-spacing:-.04em}p{line-height:1.6}a{color:inherit}@media(max-width:700px){section{grid-template-columns:1fr}}</style></head><body><h1>Two original builds. One demanding brief.</h1><p>Independent GPT-6.1 Standard builds, each with twenty minutes. Motion adds its installed skills and actual MCP workflow. These recordings show the same visitor goals on the real GPU browser.</p><p>${escape(result.summary)}</p><section><div><h2>Ordinary build and refinement</h2><video controls preload="metadata" src="/media/control.mp4"></video><p><a href="http://127.0.0.1:4344/">Explore the frozen ordinary site</a></p></div><div><h2>Motion build, inspect and repair</h2><video controls preload="metadata" src="/media/treatment.mp4"></video><p><a href="http://127.0.0.1:4345/">Explore the frozen Motion site</a></p></div></section><p>This compares complete workflows. It does not isolate a tool's causal effect or establish a general coding-agent advantage. Source, traces, recordings and measured limits are in the private repository report.</p></body></html>`);
});
servers.push(app.listen(4343,'127.0.0.1',()=>console.log('WORKFLOW_REVIEW http://127.0.0.1:4343')));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>Promise.all(servers.map(server=>new Promise(resolve=>server.close(resolve)))).then(()=>process.exit(0)));
